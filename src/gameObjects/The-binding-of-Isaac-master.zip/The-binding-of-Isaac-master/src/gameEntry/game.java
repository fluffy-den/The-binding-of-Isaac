package gameEntry;

import gameWorld.Game;

public class game {
    // Lancement du jeu
    public static void main(String[] args) {
        Game.setupAndLoop();
    }
}
