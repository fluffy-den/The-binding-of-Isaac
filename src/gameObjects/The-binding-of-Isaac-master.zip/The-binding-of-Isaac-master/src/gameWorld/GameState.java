package gameWorld;

public enum GameState {
    RUNNING,
    WIN,
    LOST
}
